<?php

require_once 'phpqrcode/qrlib.php';

$path = 'images/';
if(!is_dir($path)) {
    mkdir($path);
}

$file = $path.date("Y-m-d-h-i-s"). '.png';

$text = "Hello, world!";

QRcode::png($text,$file, 'H', 10,2);

echo '<img src =" '.$file.'">';
?>